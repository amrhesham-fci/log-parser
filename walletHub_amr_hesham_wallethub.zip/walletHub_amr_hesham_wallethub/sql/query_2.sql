SELECT 
    *
FROM
    log_parser.log_line
WHERE
    ip = '192.168.228.188';