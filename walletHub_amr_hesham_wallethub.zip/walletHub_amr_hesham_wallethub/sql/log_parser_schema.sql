CREATE DATABASE  IF NOT EXISTS `log_parser` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `log_parser`;
-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: log_parser
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `http_status_code`
--

DROP TABLE IF EXISTS `http_status_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_status_code` (
  `id` int(11) NOT NULL,
  `code` int(11) DEFAULT NULL,
  `message` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_status_code`
--

LOCK TABLES `http_status_code` WRITE;
/*!40000 ALTER TABLE `http_status_code` DISABLE KEYS */;
INSERT INTO `http_status_code` VALUES (1,200,'Ok'),(2,400,'Bad Request'),(3,401,'Unauthorized'),(4,403,'Forbidden'),(5,404,'Not Found'),(6,408,'Request Timeout'),(7,429,'Too Many Requests'),(8,500,'Internal Server Error'),(9,502,'Bad Gateway'),(10,503,'Service Unavailable'),(11,504,'Gateway Timeout');
/*!40000 ALTER TABLE `http_status_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_line`
--

DROP TABLE IF EXISTS `log_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_date` datetime DEFAULT NULL,
  `IP` varchar(15) DEFAULT NULL,
  `Request` varchar(45) DEFAULT NULL,
  `response_Status_id` int(11) DEFAULT NULL,
  `user_agent` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `statusid_idx` (`response_Status_id`),
  CONSTRAINT `statusid` FOREIGN KEY (`response_Status_id`) REFERENCES `http_status_code` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2738492 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_line`
--

LOCK TABLES `log_line` WRITE;
/*!40000 ALTER TABLE `log_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_parser_request`
--

DROP TABLE IF EXISTS `log_parser_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_parser_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) DEFAULT NULL,
  `start_date` varchar(45) DEFAULT NULL,
  `duration` varchar(45) DEFAULT NULL,
  `threshold` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_parser_request`
--

LOCK TABLES `log_parser_request` WRITE;
/*!40000 ALTER TABLE `log_parser_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_parser_request` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-18 22:37:11
