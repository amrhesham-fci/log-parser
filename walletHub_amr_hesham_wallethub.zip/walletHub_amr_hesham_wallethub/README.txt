example of the command is like the following:

java -cp "log-parser.jar"  com.wallethub.util.log.config.SpringBootConsoleApplication --accessLog=access.log --startDate=2017-01-01.13:00:00 --duration=hourly --threshold=100
